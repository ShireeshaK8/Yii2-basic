### What steps will reproduce the problem?

### What's expected?

### What do you get instead?


### Additional info

| Q                | A
| ---------------- | ---
| Yii version       |
| PHP version      |
| Operating system |
